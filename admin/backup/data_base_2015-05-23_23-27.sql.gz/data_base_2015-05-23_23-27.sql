#SKD101|data_base|29|2015.05.23 23:27:28|214|5|2|1|7|2|86|11|3|6|3|10|15|1|8|4|18|4|6|6|4|3|1|1|4|1|2

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `comment` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `files` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `feedback` VALUES
(1, 1, '2014-01-01 00:00:00', 'Василий Петрович', 'ottofonf@rambler.ru', 'Здравствуйте\r\nкак заказать вашу услугу', 'Это письмо просмотрено и оставлен комментарий', ''),
(2, 0, '2014-11-22 21:21:44', 'Сергей Петрович', 'ottofonf@rambler.ru', 'проверка формы обратной связи\r\nприкрепил файл', '', 'a:1:{i:1;a:3:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:8:\"htaccess\";s:4:\"name\";s:9:\".htaccess\";}}'),
(3, 0, '2015-03-14 13:52:11', 'rqwer', 'ottofonf@gmail.com', 'rqwerw', '', ''),
(4, 0, '2015-03-14 13:58:06', 'rqwer', 'ottofonf@gmail.com', 'rqwerw', '', ''),
(5, 0, '2015-03-17 14:16:07', 'test', 'ottofonf@rambler.ru', 'test', '', '');

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` int(10) unsigned NOT NULL,
  `template` tinyint(1) unsigned NOT NULL,
  `rank` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `images` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `gallery` VALUES
(1, 1, 2, 1, 'Природа', 'priroda', 'Природа', '', 'Природа', 'desert.jpg', 'a:1:{i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:13:\"jellyfish.jpg\";s:4:\"name\";s:9:\"Jellyfish\";s:7:\"display\";s:1:\"1\";}}'),
(2, 1, 1, 1, 'Вторая', 'vtoraya', 'Вторая', 'вторая', 'Вторая', 'lighthouse.jpg', 'a:3:{i:1;a:3:{s:4:\"name\";s:13:\"Chrysanthemum\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:17:\"chrysanthemum.jpg\";}i:2;a:3:{s:4:\"name\";s:6:\"Desert\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:10:\"desert.jpg\";}i:3;a:3:{s:4:\"name\";s:6:\"Tulips\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:10:\"tulips.jpg\";}}');

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `rank` smallint(5) unsigned NOT NULL COMMENT 'Рейтинг',
  `display` tinyint(1) unsigned NOT NULL COMMENT 'Показывать',
  `style` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'название',
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'урл',
  `localization` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'словарь',
  `dictionary` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Языки';

INSERT INTO `languages` VALUES
(1, 100, 1, 'default', 'ottofonf@rambler.ru', 'Русский', 'rus', 'ru', 'a:107:{s:9:\"site_name\";s:31:\"Интернет магазин\";s:8:\"txt_meta\";s:17:\"<script></script>\";s:8:\"txt_head\";s:100:\"Добро пожаловать!\r\n<br>Это демо-версия интернет-магазина\";s:9:\"txt_index\";s:226:\"Тут можно разместить любой текст\r\n<br/>\r\n<br/>для входа в админпанель перейдите  <a href=\"/admin.php\">по ссылке</a>\r\n<br/>логин test\r\n<br/>пароль test\";s:10:\"txt_footer\";s:758:\"<div style=\"float:right\">\r\n<!--LiveInternet counter--><script type=\"text/javascript\"><!--\r\ndocument.write(\"<a href=\'http://www.liveinternet.ru/click\' \"+\r\n\"target=_blank><img src=\'//counter.yadro.ru/hit?t15.6;r\"+\r\nescape(document.referrer)+((typeof(screen)==\"undefined\")?\"\":\r\n\";s\"+screen.width+\"*\"+screen.height+\"*\"+(screen.colorDepth?\r\nscreen.colorDepth:screen.pixelDepth))+\";u\"+escape(document.URL)+\r\n\";h\"+escape(document.title.substring(0,80))+\";\"+Math.random()+\r\n\"\' alt=\'\' title=\'LiveInternet: показано число просмотров за 24\"+\r\n\" часа, посетителей за 24 часа и за сегодня\' \"+\r\n\"border=\'0\' width=\'88\' height=\'31\'><\\/a>\")\r\n//--></script><!--/LiveInternet-->\r\n</div>\r\ncopiright &copy; abc-cms.com 2013\";s:16:\"str_no_page_name\";s:36:\"страница не найдена\";s:16:\"txt_no_page_text\";s:63:\"запрашиваемая страница не найдена\";s:8:\"wrd_more\";s:18:\"подробнее\";s:14:\"msg_no_results\";s:64:\"по данному запросу нет результатов\";s:12:\"wrd_no_photo\";s:15:\"нет фото\";s:16:\"breadcrumb_index\";s:14:\"Главная\";s:20:\"breadcrumb_separator\";s:3:\" - \";s:14:\"make_selection\";s:27:\"сделайте выбор\";s:13:\"feedback_name\";s:15:\"Ваше имя\";s:14:\"feedback_email\";s:5:\"Email\";s:13:\"feedback_text\";s:18:\"Сообщение\";s:13:\"feedback_send\";s:18:\"Отправить\";s:15:\"feedback_attach\";s:29:\"Прикрепить файл\";s:24:\"feedback_message_is_sent\";s:55:\"сообщение успешно отправлено!\";s:22:\"msg_no_required_fields\";s:65:\"Не все обязательные поля заполнены!\";s:15:\"msg_short_login\";s:43:\"Логин слишком короткий!\";s:19:\"msg_not_valid_login\";s:37:\"Не корректный логин!\";s:19:\"msg_not_valid_email\";s:32:\"Не корректный email!\";s:22:\"msg_not_valid_password\";s:66:\"Минимальная длина пароля 5 символов!\";s:21:\"msg_not_valid_captcha\";s:51:\"Неверный код подтверждения!\";s:22:\"msg_not_valid_captcha2\";s:75:\"Для отправки сообщения включите скрипты!\";s:15:\"msg_error_email\";s:175:\"Произошла ошибка с отправлением письма, если это повторится, сообщите администартору ottofonf@gmail.ru\";s:12:\"msg_no_email\";s:92:\"Данный E-mail не закреплён ни за одним пользователем!\";s:19:\"msg_duplicate_login\";s:50:\"Такой логин уже есть в базе!\";s:19:\"msg_duplicate_email\";s:45:\"Такой email уже есть в базе!\";s:23:\"msg_not_match_passwords\";s:37:\"Пароли не совпадают!\";s:13:\"profile_hello\";s:24:\"Здравствуйте\";s:12:\"profile_link\";s:27:\"личный кабинет\";s:17:\"profile_user_edit\";s:25:\"Личные данные\";s:12:\"profile_exit\";s:10:\"выйти\";s:13:\"profile_email\";s:6:\"Еmail\";s:16:\"profile_password\";s:12:\"Пароль\";s:17:\"profile_password2\";s:35:\"Подтвердите пароль\";s:20:\"profile_new_password\";s:23:\"Новый пароль\";s:12:\"profile_save\";s:18:\"Сохранить\";s:20:\"profile_registration\";s:22:\"Регистрация\";s:13:\"profile_enter\";s:10:\"Войти\";s:19:\"profile_remember_me\";s:27:\"запомнить меня\";s:12:\"profile_auth\";s:22:\"Авторизация\";s:14:\"profile_remind\";s:26:\"забыли пароль?\";s:31:\"profile_successful_registration\";s:51:\"Регистрация прошла успешно!\";s:23:\"profile_successful_auth\";s:33:\"Вы авторизированы\";s:18:\"profile_error_auth\";s:51:\"Логин и пароль не совпадают!\";s:16:\"profile_msg_exit\";s:15:\"Вы вышли\";s:21:\"profile_go_to_profile\";s:32:\"перейти в профиль\";s:21:\"profile_remind_button\";s:31:\"Отправить письмо\";s:25:\"profile_successful_remind\";s:111:\"На указанный email отправлено письмо по восстановлению пароля!\";s:12:\"shop_catalog\";s:14:\"Каталог\";s:8:\"shop_new\";s:14:\"Новинки\";s:10:\"shop_brand\";s:26:\"Производитель\";s:12:\"shop_article\";s:14:\"Артикул\";s:15:\"shop_parameters\";s:18:\"Параметры\";s:19:\"shop_product_random\";s:29:\"Случайный товар\";s:13:\"shop_currency\";s:7:\"руб.\";s:18:\"shop_filter_button\";s:10:\"Найти\";s:7:\"reviews\";s:12:\"Отзывы\";s:10:\"review_add\";s:27:\"Оставить отзыв\";s:11:\"review_name\";s:6:\"Имя\";s:12:\"review_email\";s:5:\"Email\";s:11:\"review_text\";s:10:\"Отзыв\";s:11:\"review_send\";s:18:\"Отправить\";s:14:\"review_is_sent\";s:35:\"Ваш отзыв добавлен!\";s:10:\"basket_buy\";s:12:\"Купить\";s:6:\"basket\";s:14:\"корзина\";s:12:\"basket_empty\";s:39:\"в корзине нет товаров\";s:16:\"basket_go_basket\";s:32:\"перейти в корзину\";s:14:\"basket_go_next\";s:35:\"продолжить покупки\";s:20:\"basket_product_added\";s:46:\"товар добавлен в корзину!\";s:17:\"basket_product_id\";s:2:\"ID\";s:19:\"basket_product_name\";s:29:\"Название товара\";s:20:\"basket_product_price\";s:8:\"цена\";s:20:\"basket_product_count\";s:20:\"Количество\";s:19:\"basket_product_summ\";s:10:\"Сумма\";s:19:\"basket_product_cost\";s:18:\"Стоимость\";s:21:\"basket_product_delete\";s:14:\"удалить\";s:12:\"basket_total\";s:10:\"Итого\";s:14:\"basket_profile\";s:25:\"Личные данные\";s:15:\"basket_delivery\";s:16:\"Доставка\";s:20:\"basket_delivery_cost\";s:35:\"Стоимость доставки\";s:14:\"basket_comment\";s:22:\"Комментарий\";s:12:\"basket_order\";s:27:\"Оформить заказ\";s:13:\"basket_orders\";s:35:\"Статистика заказов\";s:17:\"basket_order_name\";s:10:\"Заказ\";s:17:\"basket_order_from\";s:4:\"от\";s:19:\"basket_order_status\";s:12:\"статус\";s:17:\"basket_order_date\";s:8:\"дата\";s:17:\"basket_view_order\";s:47:\"посмотреть заказ на сайте\";s:11:\"market_name\";s:14:\"Магазин\";s:14:\"market_company\";s:46:\"Интернет магазин товаров\";s:15:\"market_currency\";s:3:\"RUR\";s:10:\"letter_top\";s:37:\"Текст в шапке письма\";s:13:\"letter_footer\";s:41:\"Текст в подвале письма\";s:13:\"subscribe_top\";s:41:\"Текст в шапке рассылки\";s:16:\"subscribe_bottom\";s:45:\"Текст в подвале рассылки\";s:28:\"subscribe_letter_failure_str\";s:90:\"Если вы хотите отписаться от рассылки нажмите на \";s:29:\"subscribe_letter_failure_link\";s:12:\"ссылку\";s:19:\"subscribe_on_button\";s:22:\"Подписаться\";s:20:\"subscribe_on_success\";s:38:\"Вы успешно подписаны\";s:24:\"subscribe_on_letter_name\";s:52:\"Подписан новый пользователь\";s:22:\"subscribe_failure_text\";s:64:\"Подтвердите, что хотите отписаться\";s:24:\"subscribe_failure_button\";s:20:\"Отписаться\";s:25:\"subscribe_failure_success\";s:21:\"Вы отписаны\";}');

DROP TABLE IF EXISTS `letter_templates`;
CREATE TABLE `letter_templates` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `receiver` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `letter_templates` VALUES
(1, '', 'feedback', 'Обратная связь', '', ''),
(2, '', 'basket', 'Заказ', '', ''),
(3, '', 'remind', 'Восстановление пароля', '', ''),
(4, '', 'registration', 'Регистрация', '', ''),
(5, '', 'shop_review', 'Уведомление о добавлении отзыва', '', ''),
(6, '', 'subscribe_failure', 'Отписка пользователя', '', ''),
(7, '', 'subscribe_on', 'Подписан новый пользователь', '', '');

DROP TABLE IF EXISTS `letters`;
CREATE TABLE `letters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `sender_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `receiver` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_sent` (`date_sent`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `letters` VALUES
(1, '2014-11-23 17:31:27', '2014-11-23 17:31:41', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'ottofonf@gmail.com', 'Первая пробная рассылка', '<body style=\"margin:0; padding:0; font:14px/18px Arial\">\r\n<div style=\"margin:auto; width:800px; padding:20px\">\r\n\r\n	<div style=\"\">Текст в шапке рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">текст первой рассылки\r\n<br />\r\nвот такой</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">Текст в подвале рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"font:11px/15px Arial\">\r\n		Если вы хотите отписаться от рассылки нажмите на 		<a href=\"http://_abc/podpiska/unsubscribe/ottofonf@gmail.com/c5e5cb539d05511405ce755ecf21b2f9/\">ссылку</a>\r\n	</div>\r\n\r\n</div>\r\n</body>'),
(2, '2014-11-23 17:31:27', '2014-11-23 17:47:12', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'ottofonf@rambler.ru', 'Первая пробная рассылка', '<body style=\"margin:0; padding:0; font:14px/18px Arial\">\r\n<div style=\"margin:auto; width:800px; padding:20px\">\r\n\r\n	<div style=\"\">Текст в шапке рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">текст первой рассылки\r\n<br />\r\nвот такой</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">Текст в подвале рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"font:11px/15px Arial\">\r\n		Если вы хотите отписаться от рассылки нажмите на 		<a href=\"http://_abc/podpiska/unsubscribe/ottofonf@rambler.ru/adebd7e8bd633da8589c21702dd496d3/\">ссылку</a>\r\n	</div>\r\n\r\n</div>\r\n</body>');

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `date` datetime NOT NULL COMMENT 'дата создания лога',
  `user` int(10) unsigned NOT NULL COMMENT 'ИД юсера который вносил изменения',
  `module` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'модуль в котором внесли изменения',
  `parent` int(10) unsigned NOT NULL COMMENT 'ИД редактируемой записи',
  `type` tinyint(1) unsigned NOT NULL COMMENT 'тип действия (создание, редактирование, удаление))',
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=87 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Логи';

INSERT INTO `logs` VALUES
(1, '2015-05-23 21:00:07', 1, 'shop_items', 1, 1),
(2, '2015-05-23 21:58:06', 1, 'shop_products', 1, 2),
(3, '2015-05-23 22:01:57', 1, 'shop_products', 1, 2),
(4, '2015-05-23 22:03:46', 1, 'shop_products', 1, 2),
(5, '2015-05-23 22:05:04', 1, 'shop_products', 1, 2),
(6, '2015-05-23 22:10:15', 1, 'shop_products', 1, 2),
(7, '2015-05-23 22:13:02', 1, 'shop_products', 1, 2),
(8, '2015-05-23 22:13:35', 1, 'shop_products', 1, 2),
(9, '2015-05-23 22:14:03', 1, 'shop_products', 1, 2),
(10, '2015-05-23 22:16:27', 1, 'shop_products', 1, 2),
(11, '2015-05-23 22:17:43', 1, 'shop_products', 1, 2),
(12, '2015-05-23 22:21:44', 1, 'shop_products', 1, 2),
(13, '2015-05-23 22:31:09', 1, 'shop_products', 1, 2),
(14, '2015-05-23 22:31:59', 1, 'shop_products', 1, 2),
(15, '2015-05-23 22:32:04', 1, 'shop_products', 1, 2),
(16, '2015-05-23 22:32:58', 1, 'shop_products', 1, 2),
(17, '2015-05-23 22:33:08', 1, 'shop_products', 1, 2),
(18, '2015-05-23 22:34:08', 1, 'shop_products', 1, 2),
(19, '2015-05-23 22:34:35', 1, 'shop_products', 1, 2),
(20, '2015-05-23 22:35:01', 1, 'shop_products', 1, 2),
(21, '2015-05-23 22:35:18', 1, 'shop_products', 1, 2),
(22, '2015-05-23 22:37:17', 1, 'shop_products', 1, 2),
(23, '2015-05-23 22:37:30', 1, 'shop_products', 1, 2),
(24, '2015-05-23 22:37:44', 1, 'shop_products', 1, 2),
(25, '2015-05-23 22:37:46', 1, 'shop_products', 1, 2),
(26, '2015-05-23 22:37:49', 1, 'shop_products', 1, 2),
(27, '2015-05-23 22:37:51', 1, 'shop_products', 1, 2),
(28, '2015-05-23 22:37:52', 1, 'shop_products', 1, 2),
(29, '2015-05-23 22:37:56', 1, 'shop_products', 1, 2),
(30, '2015-05-23 22:37:57', 1, 'shop_products', 1, 2),
(31, '2015-05-23 22:37:58', 1, 'shop_products', 1, 2),
(32, '2015-05-23 22:38:07', 1, 'shop_products', 1, 2),
(33, '2015-05-23 22:38:29', 1, 'shop_products', 1, 2),
(34, '2015-05-23 22:39:08', 1, 'shop_products', 1, 2),
(35, '2015-05-23 22:41:05', 1, 'shop_products', 1, 2),
(36, '2015-05-23 22:41:48', 1, 'shop_products', 1, 2),
(37, '2015-05-23 22:45:50', 1, 'shop_products', 1, 2),
(38, '2015-05-23 22:46:02', 1, 'shop_items', 18, 2),
(39, '2015-05-23 22:46:02', 1, 'shop_items', 17, 2),
(40, '2015-05-23 22:46:02', 1, 'shop_items', 16, 2),
(41, '2015-05-23 22:46:03', 1, 'shop_items', 15, 2),
(42, '2015-05-23 22:46:03', 1, 'shop_items', 14, 2),
(43, '2015-05-23 22:48:16', 1, 'shop_products', 1, 2),
(44, '2015-05-23 22:48:56', 1, 'shop_products', 1, 2),
(45, '2015-05-23 22:51:00', 1, 'shop_products', 1, 2),
(46, '2015-05-23 22:52:08', 1, 'shop_products', 1, 2),
(47, '2015-05-23 22:56:18', 1, 'shop_products', 1, 2),
(48, '2015-05-23 22:58:46', 1, 'shop_products', 1, 2),
(49, '2015-05-23 22:59:23', 1, 'shop_products', 1, 2),
(50, '2015-05-23 23:03:01', 1, 'shop_products', 1, 2),
(51, '2015-05-23 23:03:05', 1, 'shop_products', 1, 2),
(52, '2015-05-23 23:03:06', 1, 'shop_products', 1, 2),
(53, '2015-05-23 23:03:10', 1, 'shop_products', 1, 2),
(54, '2015-05-23 23:03:29', 1, 'shop_products', 1, 2),
(55, '2015-05-23 23:04:44', 1, 'shop_products', 1, 2),
(56, '2015-05-23 23:04:50', 1, 'shop_products', 1, 2),
(57, '2015-05-23 23:04:51', 1, 'shop_products', 1, 2),
(58, '2015-05-23 23:06:29', 1, 'shop_products', 1, 2),
(59, '2015-05-23 23:06:32', 1, 'shop_products', 1, 2),
(60, '2015-05-23 23:06:33', 1, 'shop_products', 1, 2),
(61, '2015-05-23 23:06:42', 1, 'shop_products', 1, 2),
(62, '2015-05-23 23:06:43', 1, 'shop_products', 1, 2),
(63, '2015-05-23 23:06:50', 1, 'shop_products', 1, 2),
(64, '2015-05-23 23:07:02', 1, 'shop_products', 1, 2),
(65, '2015-05-23 23:09:16', 1, 'shop_products', 1, 2),
(66, '2015-05-23 23:09:38', 1, 'shop_products', 1, 2),
(67, '2015-05-23 23:10:29', 1, 'shop_products', 1, 2),
(68, '2015-05-23 23:10:50', 1, 'shop_products', 1, 2),
(69, '2015-05-23 23:11:16', 1, 'shop_products', 1, 2),
(70, '2015-05-23 23:12:33', 1, 'shop_products', 1, 2),
(71, '2015-05-23 23:12:52', 1, 'shop_products', 1, 2),
(72, '2015-05-23 23:13:15', 1, 'shop_products', 1, 2),
(73, '2015-05-23 23:13:43', 1, 'shop_products', 1, 2),
(74, '2015-05-23 23:14:02', 1, 'shop_products', 1, 2),
(75, '2015-05-23 23:19:05', 1, 'shop_products', 1, 2),
(76, '2015-05-23 23:19:13', 1, 'shop_products', 1, 2),
(77, '2015-05-23 23:19:41', 1, 'shop_products', 1, 2),
(78, '2015-05-23 23:19:47', 1, 'shop_products', 1, 2),
(79, '2015-05-23 23:19:55', 1, 'shop_products', 1, 2),
(80, '2015-05-23 23:20:04', 1, 'shop_products', 1, 2),
(81, '2015-05-23 23:20:39', 1, 'shop_products', 1, 2),
(82, '2015-05-23 23:21:26', 1, 'shop_products', 1, 2),
(83, '2015-05-23 23:24:58', 1, 'shop_products', 1, 2),
(84, '2015-05-23 23:25:14', 1, 'shop_products', 1, 2),
(85, '2015-05-23 23:25:39', 1, 'shop_products', 1, 2),
(86, '2015-05-23 23:25:52', 1, 'shop_products', 1, 2);

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `user` int(10) unsigned NOT NULL COMMENT 'автор новости',
  `display` tinyint(1) NOT NULL COMMENT 'показывать/скрыть',
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `user` (`user`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=18 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Новости';

INSERT INTO `news` VALUES
(1, '2010-12-28 20:39:51', 2, 1, 'В Швеции уборщица угнала поезд', '<p>Такое можно увидеть не часто &ndash; в Швеции уборщица, по непонятным причинам, угнала поезд, свела его с рельсов и врезалась в жилой дом. К счастью, никто, кроме женщины, в результате не пострадал.&nbsp;<br /><br />Инцидент произошёл 15 января 2012 года. Согласно полиции, женщина, возрастом в районе 20-30 лет, которая работала уборщицей в местной транспортной компании, угнала поезд рано утром. Как именно она получила ключ от поезда, не сообщается.&nbsp;<br /><br />Уборщица вела поезд па большой скорости, свела его с рельсов и врезалась в дом&raquo; - сказал пресс-секретарь организации &laquo;городской транспорт Стокгольма&raquo; Джаспер Петтерссон (Jesper Pettersson).</p>', 'В Швеции уборщица угнала поезд', 'v-shvetsii-uborshchitsa-ugnala-poezd', 'поезд, не, угнала, уборщица, его, врезалась, швеции, свела, дом, рельсов, можно, счастью, непонятным, такое, увидеть, жилой, причинам, часто, по', 'Такое можно увидеть не часто в Швеции уборщица, по непонятным причинам, угнала поезд, свела его с рельсов и врезалась в жилой дом. К счастью,'),
(2, '2011-11-04 12:59:28', 1, 1, 'Белый Дом не даст денег на Звезду Смерти', '<p>Администрация президента США официально отказалась запустить программу по созданию космической станции \"Звезда смерти\" (Death Star), сообщает NBCNews в пятницу, 11 января.<br /><br />Петиция с просьбой о постройке \"Звезды смерти\" была обнародована в декабре 2012 года в рамках программы законотворческих инициатив избирателей \"We the People\". Свои подписи под петицией поставили более 25 тысяч человек после чего, по правилам \"We the People\", администрация президента была обязана рассмотреть обращение и дать на него ответ.<br /><br />Отвечать на петицию о строительстве \"Звезды смерти\" пришлось главе департамента науки и космоса Административно-бюджетного управления Белого дома Полу Шоукроссу (Paul Shawcross). Он назвал как минимум три причины, по которым этот проект не будет реализован: 1. \"Строительство \"Звезды смерти\" обойдется в 850 квадриллионов долларов, а мы стараемся сократить бюджетный дефицит, а не увеличить его\"; 2. \"Администрация президента не поддерживает идею уничтожения планет\"; 3. \"Зачем тратить огромные средства налогоплательщиков на \"Звезду смерти\" с фундаментальным недостатком, которым сможет воспользоваться пилот одноместного космического корабля?\".<br /><br />Далее Шоукросс кратко перечислил основные направления, по которым развивается американская программа по исследованию космоса, упомянув Международную космическую станцию и марсоходы, в том числе оснащенные лазерной пушкой. В заключение он пожелал автору петиции найти себе применение в сфере науки, технологии, инженерии или математики, пообещав, что в этом случае \"с ним пребудет Сила\".<br /><br />На отказ от строительства \"Звезды смерти\" уже отреагировал пользователь твиттера \"Дарт Вейдер\", написавший: \"Серьезная ошибка, господин президент! Лазеров размером с планету всегда не хватает\".</p>', 'Белый Дом не даст денег на Звезду Смерти', 'belyi-dom-ne-dast-deneg-na-zvezdu-smerti', 'смерти, по, на, не, президента, администрация, звезды, которым, сообщает, star, death, космоса, звезда, была, people, он, звезду, станции, науки', 'Администрация президента США официально отказалась запустить программу по созданию космической станции \"Звезда смерти\" (Death Star), сообщает'),
(3, '2011-11-04 13:03:33', 1, 1, 'Грабитель пожаловался полиции на домовладельца с пистолетом', '<p>В американском городе Спрингтаун, штат Техас, был арестован грабитель, который сам позвонил в полицию, чтобы пожаловаться на владельца дома, который задержал его, используя оружие.&nbsp;<br /><br />Подозреваемый Кристофер Мур (Christopher Moore) позвонил в полицию после неудавшегося ограбления. Пока мужчина сидел в своём автомобиле, припаркованном у дома, владелец дома Джеймс Героу (James Gerow) и его сын подошли к нему и навели на него пистолеты.<br /><br />Испуганный Мур позвонил в полицию и сказал им, что двое мужчин держат его в автомобиле, угрожая оружием. В это время жена владельца дома сама позвонила в полицию и подтвердила слова Мура, но добавила, что Мур был преступником, который только что пытался ограбить их дом.</p>', 'Грабитель пожаловался полиции на домовладельца с пистолетом', 'grabitel-pozhalovalsya-politsii-na-domovladeltsa-s-pistoletom', 'полицию, позвонил, который, дома, на, грабитель, мур, владельца, его, что, был, пожаловаться, сам, чтобы, автомобиле, городе, американском', 'В американском городе Спрингтаун, штат Техас, был арестован грабитель, который сам позвонил в полицию, чтобы пожаловаться на владельца'),
(4, '2011-11-04 13:14:48', 1, 1, 'Бог велел женщине нарушить ПДД', '<p>В американском городе Форт-Пирc, штат Флорида, была арестована женщина, которая совершила несколько нарушений ПДД. Женщина сказала полицейским, что нарушила правила дорожного движения \"по указаниям Бога\".<br /><br />41-летняя Мелисса Миллер (Melissa Miller) была арестована. Полицейские остановили её, когда она ехала со скоростью 100 миль в час по дороге с ограничением скорости до 30 миль в час и постоянно сигналила.&nbsp;<br /><br />Когда полицейские спросили её, почему она нарушила правила, она сказала, что \"её направлял Святой Дух\", а сигналила она потому, что &laquo;ей Бог велел так поступить&raquo;.</p>', 'Бог велел женщине нарушить ПДД', 'bog-velel-zhenshchine-narushit-pdd', 'женщина, она, арестована, сказала, была, что, пдд, правила, нарушила, час, полицейские, городе, когда, велел, по, сигналила, нарушений, флорида', 'В американском городе Форт-Пирc, штат Флорида, была арестована женщина, которая совершила несколько нарушений ПДД. Женщина сказала'),
(5, '2011-11-05 13:25:56', 1, 1, 'Мужчина с ведром на голове ограбил ресторан', '<p>Любой более-менее умный грабитель знает, что успешное ограбление требует хорошей маскировки. Один грабитель в США понял это слишком поздно и решил импровизировать, надев на голову ведро.&nbsp;<br /><br />В надежде заработать быстрых денег, 23-летний Ричард Будроу (Richard Boudreaux) решил ограбить какое-нибудь заведение рядом со своим домом в городе Слиделл, штат Луизиана.&nbsp;<br /><br />Целью мужчины стал ресторан морской кухни, в котором он работал. Он пробрался в ресторан ночью, но вспомнил, что в ресторане были установлены камеры скрытого видео-наблюдения. Будроу понял, что не взял с собой никакой маски, чтобы прикрыть лицо, и что он может засветиться.<br /><br />Преступник решил исправить ситуацию, надев на голову ведро, однако сделал он это слишком поздно &ndash; одна из камер успела снять его лицо. После инцидента полицейские быстро нашли мужчину и арестовали его.<br /><br />&laquo;Будроу довольно хорошо подготовился к ограблению &ndash; он надел перчатки, чтобы не оставлять отпечатков, взял с собой различные инструменты для взлома дверей&raquo; - сказал пресс-секретарь местной полиции. &laquo;Однако он забыл про одну важную вещь &ndash; спрятать своё лицо. Он надел на голову ведро, уже находясь внутри ресторана, но камеры успели заснять его лицо&raquo;.</p>', 'Мужчина с ведром на голове ограбил ресторан', 'muzhchina-s-vedrom-na-golove-ograbil-restoran', 'он, что, лицо, грабитель, на, голову, будроу, ведро, понял, слишком, это, ресторан, его, решил, взял, но, надел, камеры, не, собой, поздно, чтобы', 'Любой более-менее умный грабитель знает, что успешное ограбление требует хорошей маскировки. Один грабитель в США понял это слишком'),
(9, '2011-11-05 13:30:21', 1, 1, 'Американец хотел обворовать магазин, чтобы понравиться девушке', '<p>Некоторые люди говорят, что в наше время больше не существует джентльменов, способных достойно ухаживать за девушками, но они ошибаются &ndash; этот мужчина был готов на всё, лишь бы угодить любимой девушке.<br /><br />48-летний американец Джеймс Фленнекен (James Flenniken), житель города Сарасота, штат Флорида, решил тщательно подготовиться к свиданию с девушкой &ndash; он попытался украсть из магазина Walmart вино и бифштексы, чтобы устроить романтический ужин.<br /><br />Но его план не удался. Когда он попытался вынести еду и вино из магазина не заплатив, его задержали охранники. Работники магазина вызвали полицию, и Фленнекен был арестован.<br /><br />Полицейские сказали, что когда они спросили у него, почему он попытался украсть еду, он был ничуть не смущён, и сказал им, что просто хотел &laquo;понравиться девушке&raquo;. На данный момент он находится под стражей в местной тюрьме</p>', 'Американец хотел обворовать магазин, чтобы понравиться девушке', 'amerikanets-hotel-obvorovat-magazin-chtoby-ponravitsya-devushke', 'не, он, что, магазина, девушке, попытался, но, они, был, ошибаются, еду, когда, вино, фленнекен, американец, украсть, из, за, на, девушками, люди', 'Некоторые люди говорят, что в наше время больше не существует джентльменов, способных достойно ухаживать за девушками, но они ошибаются'),
(10, '2011-11-05 13:30:26', 1, 1, 'Американец хотел оживить тело умершего отца', '<p>В американском городе Детроит, штат Мичиган, был арестован мужчина, который похитил с кладбища тело своего покойного отца, надеясь оживить его.&nbsp;<br /><br />Инцидент произошёл 14 января 2013 года. 48-лктний Винцент Брайт (Vincent Bright) и ещё один мужчина, имя которого не было афишировано, пришли на кладбище и вырыли тело покойного Кларенса Брайта (Clarence Bright), который был похоронён несколько часов назад.&nbsp;<br /><br />Полицейские, по информации, полученной от свидетелей и членов семьи Брайта, посчитали Винцента основным подозреваемым и прибыли к нему домой. Тело покойного мужчины было найдено в морозильной камере в подвале дома, а Винцент был арестован. Также полицейские арестовали мужчину, который помогал Винценту.&nbsp;<br /><br />Брайт рассказал полицейским, что украл тело отца из кладбища, надеясь, что он &laquo;чудом восстанет из мёртвых&raquo;.</p>', 'Американец хотел оживить тело умершего отца', 'amerikanets-hotel-ozhivit-telo-umershego-ottsa', 'тело, был, который, отца, покойного, мужчина, арестован, оживить, кладбища, надеясь, что, из, винцент, было, брайта, bright, брайт, полицейские', 'В американском городе Детроит, штат Мичиган, был арестован мужчина, который похитил с кладбища тело своего покойного отца, надеясь оживить'),
(12, '2013-05-27 23:44:20', 0, 1, 'Американец заехал прямо в ресторан, чтобы заказать еду', '<p>Вместо того чтобы подъехать к окошку для обслуживания автомобилистов, чтобы заказать пиццу, один житель США въехал прямо внутрь ресторана, протаранив входную дверь.<br /><br />Работники ресторана быстрого питания Valentino\'s Pizza shop в городе Линкольн, штат Небраска, были немало напуганы странным клиентом, который врезался в здание ресторана и попытался сделать заказ, как ни в чём не бывало.&nbsp;<br /><br />Мужчина, имя которого не было афишировано, был доставлен в госпиталь, когда на место прибыли полицейские и скорая помощь, но о том, получил ли он какие-либо повреждения, ничего не сообщается.<br /><br />Один из свидетелей необычного инцидента сказал, что мужчина был вовсе не смущён произошедшим, как будто делает так каждый день, и не похоже, чтобы в тот момент он был пьян.</p>', 'Американец заехал прямо в ресторан, чтобы заказать еду', 'amerikanets-zaehal-pryamo-v-restoran-chtoby-zakazat-edu', 'чтобы, не, ресторана, один, заказать, прямо, был, сша, житель, въехал, мужчина, он, пиццу, внутрь, как, вместо, автомобилистов, того, подъехать', 'Вместо того чтобы подъехать к окошку для обслуживания автомобилистов, чтобы заказать пиццу, один житель США въехал прямо внутрь'),
(13, '2013-05-27 23:44:51', 0, 1, 'Вместо ювелирного магазина грабители попали в KFC', '<p>В австралийском городе Бьюдесерт были арестованы два грабителя, которые &laquo;ошиблись помещением&raquo; - преступники планировали ограбить ювелирный магазин, но по ошибке пробрались в ресторан быстрого питания KFC.&nbsp;<br /><br />Согласно газете ABC News, ограбление произошло 31 декабря, 2012 года. Дуэйн Дулан (Dwayne Doolan) и Питер Уэлш (Peter Welsh) хотели попасть в ювелирный магазин, проломив стену в здание, но они проломили её не в том месте, и попали в находящийся радом ресторан KFC.<br /><br />Хоть план и провалился, преступники не захотели уходить с пустыми руками, и решили ограбить ресторан. Угрожая металлической трубой, мужчины приказали работникам ресторана отдать им деньги. Получив две с половиной тысячи долларов, преступники сбежали.&nbsp;<br /><br />Работники ресторана вызвали полицию, и, так как преступники ушли с места преступления пешком, полицейские нашли их не далеко от места преступления. Они были арестованы по обвинению в вооружённом ограблении. На данный момент они находятся под стражей.</p>', 'Вместо ювелирного магазина грабители попали в KFC', 'vmesto-yuvelirnogo-magazina-grabiteli-popali-v-kfc', 'преступники, были, ограбить, арестованы, ресторан, они, не, места, планировали, ювелирный, преступления, по, ресторана, магазин, но', 'В австралийском городе Бьюдесерт были арестованы два грабителя, которые ошиблись помещением - преступники планировали ограбить'),
(14, '2013-05-27 23:45:15', 0, 1, 'Преступник оставил за собой след из чипсов Сheetos', '<p>В американском городе Колумбия, штат Южная Каролина, был арестован мужчина, который ограбил магазин, и оставил за собой длинный след кукурузных чипсов Сheetos, который привёл полицейских прямо к его дому.&nbsp;<br /><br />Согласно полиции, 19-литний Остин Ли Уэстфол Преслер (Austin Lee Westfall Presler) ограбил магазин 6 января 2012 года. Он разбил окно, пробрался в магазин и взял пиво, сигареты, закуски и энергетические напитки.&nbsp;<br /><br />Но полицейские быстро нашли Преслера по его собственной вине &ndash; в спешке мужчина нечаянно продырявил несколько упаковок чипсов Сheetos, и след из чипсов и крошек привёл полицейских прямо к входной двери дома знакомого Преслера, у которого он гостил.&nbsp;<br /><br />Полицейские нашли Преслера внутри дома вместе с украденными вещами и арестовали его по обвинению в ограблении. На данный момент он находится под стражей в местной тюрьме. Владелец магазина сказал, что вещи, которые украл Преслер, стоили очень мало &ndash; гораздо дороже ему обойдётся починка окна.</p>', 'Преступник оставил за собой след из чипсов Сheetos', 'prestupnik-ostavil-za-soboi-sled-iz-chipsov-sheetos', 'магазин, след, чипсов, ограбил, преслера, который, мужчина, собой, он, за, сheetos, оставил, его, прямо, нашли, полицейские, полицейских, по', 'В американском городе Колумбия, штат Южная Каролина, был арестован мужчина, который ограбил магазин, и оставил за собой длинный след'),
(17, '2012-10-17 09:09:07', 0, 1, 'еще одна новость', '', 'еще одна новость', 'eshche-odna-novost', 'новость, одна, еще', 'еще одна новость');

DROP TABLE IF EXISTS `order_deliveries`;
CREATE TABLE `order_deliveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `free` decimal(10,2) unsigned NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `order_deliveries` VALUES
(1, 1, 10, 'Курьерская доставка', '100.00', '1000.00', 'Осуществляется на следующий день.\r\nСтоимость доставки 100 рублей.\r\nПри заказе на сумму больше 1000 рублей бесплатно'),
(2, 1, 5, 'Самовывоз', '0.00', '0.00', 'На адрес'),
(3, 1, 1, 'Наложенным платежом', '300.00', '0.00', '');

DROP TABLE IF EXISTS `order_payments`;
CREATE TABLE `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `merchant` tinyint(1) unsigned NOT NULL,
  `rank` tinyint(4) NOT NULL,
  `name` varchar(255) /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_bin */ NOT NULL,
  `text` text /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `order_payments` VALUES
(1, 0, 1, 10, 'Наличный рассчет', ''),
(2, 1, 3, 9, 'Yandex', ''),
(3, 1, 4, 8, 'Webmoney', ''),
(4, 1, 7, 7, 'Банковская карта', ''),
(5, 1, 5, 6, 'QIWI', ''),
(6, 1, 6, 1, 'Терминал', '');

DROP TABLE IF EXISTS `order_types`;
CREATE TABLE `order_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` tinyint(3) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `order_types` VALUES
(1, 1, 1, 'новый заказ', 'описание нового заказа'),
(2, 2, 1, 'в обработке', 'ваш заказ обрабатывается нашими менеджерами'),
(3, 3, 1, 'выполненный', 'заказ выполненный');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `date_paid` datetime NOT NULL,
  `type` tinyint(1) NOT NULL,
  `paid` tinyint(1) unsigned NOT NULL,
  `payment` tinyint(1) unsigned NOT NULL,
  `user` int(11) unsigned DEFAULT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `basket` text /*!40101 COLLATE utf8_unicode_ci */,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `orders` VALUES
(1, '2013-10-10 17:38:50', '2014-12-21 13:43:08', 1, 1, 0, 1, 'ottofonf@gmail.com', '1556.00', 'a:4:{s:8:\"products\";a:1:{i:1;a:4:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:16:\"Samsung Series 3\";s:5:\"count\";s:1:\"2\";s:5:\"price\";s:3:\"682\";}}s:8:\"delivery\";a:2:{s:4:\"type\";s:1:\"3\";s:4:\"cost\";s:6:\"300.00\";}s:4:\"text\";s:16:\"куенукен\";s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}}'),
(2, '2014-04-02 20:24:46', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@rambler.ru', '928.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:16:\"Samsung Series 3\";s:5:\"price\";s:3:\"628\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:5:\"qweqw\";}i:1;a:1:{i:0;s:7:\"wertwer\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:3:\"gst\";}}s:4:\"text\";s:15:\"wertwert\r\nwertw\";}'),
(3, '2014-04-02 20:25:43', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@rambler.ru', '838.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:10:\"Asus K53BR\";s:5:\"price\";s:3:\"538\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:5:\"qweqw\";}i:1;a:1:{i:0;s:7:\"ertwert\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:4:\"wert\";}}s:4:\"text\";s:7:\"wertwer\";}'),
(4, '2015-01-03 16:43:27', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@gmail.com', '7373.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:16:\"Samsung Series 3\";s:5:\"price\";s:4:\"6373\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:1;s:4:\"cost\";s:7:\"1000.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:4:\"poop\";}'),
(5, '2015-01-03 16:44:34', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@gmail.com', '1223.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:31:\"Acer Aspire AS5755G-2634G50Mnks\";s:5:\"price\";s:4:\"1223\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:1;s:4:\"cost\";i:0;}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:2:\"l\'\";}'),
(6, '2015-01-03 17:37:50', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@gmail.com', '1523.00', 'a:4:{s:8:\"products\";a:1:{i:1;a:4:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:31:\"Acer Aspire AS5755G-2634G50Mnks\";s:5:\"price\";s:4:\"1223\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:8:\"пвап\";}'),
(7, '2015-01-03 17:38:54', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@gmail.com', '1523.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:31:\"Acer Aspire AS5755G-2634G50Mnks\";s:5:\"price\";s:4:\"1223\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:10:\"кцуцу\";}'),
(8, '2015-03-17 13:48:17', '0000-00-00 00:00:00', 1, 0, 0, 1, 'admin', '1205.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:10:\"Asus N53SV\";s:5:\"price\";s:3:\"905\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:0:\"\";}'),
(9, '2015-03-17 14:07:56', '0000-00-00 00:00:00', 1, 0, 0, 1, '', '6673.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:16:\"Samsung Series 3\";s:5:\"price\";s:4:\"6373\";s:5:\"count\";s:1:\"1\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:0:\"\";}'),
(10, '2015-04-12 15:12:16', '0000-00-00 00:00:00', 1, 0, 0, 1, 'ottofonf@gmail.com', '13046.00', 'a:4:{s:8:\"products\";a:1:{i:0;a:4:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:14:\"Samsung Series\";s:5:\"price\";s:4:\"6373\";s:5:\"count\";s:1:\"2\";}}s:8:\"delivery\";a:2:{s:4:\"type\";i:3;s:4:\"cost\";s:6:\"300.00\";}s:4:\"user\";a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}s:4:\"text\";s:5:\"thfhg\";}');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `language` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `left_key` int(10) unsigned NOT NULL,
  `right_key` int(10) unsigned NOT NULL,
  `level` smallint(6) DEFAULT '1',
  `display` tinyint(1) NOT NULL,
  `menu` tinyint(1) unsigned NOT NULL,
  `menu2` tinyint(1) unsigned NOT NULL,
  `module` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT 'pages',
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `rank` (`display`),
  KEY `module` (`module`),
  KEY `left_key` (`left_key`),
  KEY `right_key` (`right_key`),
  KEY `level` (`level`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=21 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ PACK_KEYS=0;

INSERT INTO `pages` VALUES
(1, 1, 0, 1, 2, 1, 1, 0, 0, 'index', 'Главная', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'glavnaya', 'Главная', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor'),
(2, 1, 0, 19, 20, 1, 1, 0, 0, 'registration', 'Регистрация', '', 'registration', 'Регистрация', 'регистрация', 'Регистрация'),
(3, 1, 0, 21, 22, 1, 1, 0, 0, 'profile', 'Личный кабинет', '', 'profile', 'Личный кабинет', 'кабинет, личный', 'Личный кабинет'),
(4, 1, 0, 23, 24, 1, 1, 0, 0, 'login', 'Авторизация', '', 'login', 'Авторизация', 'авторизация', 'Авторизация'),
(6, 1, 0, 9, 10, 1, 1, 1, 1, 'news', 'Новости', '<p>vdfdп</p>', 'novosti', 'Новости', '', 'vdfd Новости'),
(7, 1, 0, 11, 14, 1, 1, 1, 1, 'pages', 'О нас', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>\n<p>&nbsp;</p>\n<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'o-nas', 'О нас', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor'),
(17, 1, 0, 29, 30, 1, 1, 0, 1, 'subscribe', 'Подписка', '', 'podpiska', 'Подписка', 'подписка', 'Подписка'),
(8, 1, 0, 17, 18, 1, 1, 1, 0, 'pages', 'Контакты', '<p>Ленинград, 3-я улица строителей, д.12</p>', 'kontakty', 'Контакты', 'dolor, dolore, exercitation, ullamco, nostrud, veniam, laboris, quis, nisi, aute, irure, duis, consequat, commodo, minim, aliquip, consectetur, adipisicing, ipsum, lorem, enim, elit, amet, eiusmod, aliqua, magna, labore, incididunt, tempor, culpa', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor'),
(9, 1, 0, 5, 6, 1, 1, 1, 0, 'shop', 'Каталог', '', 'katalog', 'Каталог', 'каталог', 'Каталог'),
(11, 1, 0, 25, 26, 1, 1, 0, 0, 'remind', 'Востановление пароля', '<p>Введите свой электронный адрес, на него будет выслана информация по востановлению пароля.</p>', 'remind', 'Востановление пароля', 'пароля, востановление', 'Востановление пароля'),
(12, 1, 0, 27, 28, 1, 1, 0, 0, 'basket', 'Корзина', '', 'korzina', 'Корзина', 'корзина', 'Корзина'),
(13, 1, 7, 12, 13, 2, 1, 1, 0, 'feedback', 'Обратная связь', '', 'obratnaya-svyaz', 'Обратная связь', 'связь, обратная', 'Обратная связь'),
(14, 1, 0, 3, 4, 1, 1, 1, 1, 'pages', 'О компании', '<p>Услужливый американец принял участие в ограблении банка, даже не подозревая об этом. Пожилая женщина, которая попросила его подвезти её до банка в штате Миннесота, оказалась грабителем.&nbsp;<br /><br />70-летняя Сандра Леанн Бэфке (Sandra Leanne Bathke) попросила 26-лентнего Люка Веймерта (Luke Weimert) подвезти её до банка. Он согласился, подумав, что женщина всего лишь хочет снять со счета деньги.<br /><br />Когда они прибыли в банк, Бэфке зашла внутрь и потребовала у работников деньги. Она сказала им, что у неё есть оружие. Веймерт ждал в машине, пока Бэфке совершала ограбление.&nbsp;<br /><br />Даже когда женщина вернулась в машину, и Веймерт повёз её домой, он так и не догадался, что произошло. Он подумал, что что-то не так, лишь когда увидел полицейских, которые поджидали их у дома Бэфке.<br /><br />&laquo;Я не понимал, что здесь происходит&raquo; - сказал Веймерт газете Mankato Free Press. &laquo;Полиция остановила нас и заставила выйти из машины, угрожая оружием&raquo;. Затем полиция рассказала ему, что именно он наделал своим добрым поступком.</p>', 'o-kompanii', 'О компании', 'не, что, банка, женщина, бэфке, он, подвезти, веймерт, когда, до, попросила, даже, лишь, так, участие, услужливый, полиция, американец, принял', 'Услужливый американец принял участие в ограблении банка, даже не подозревая об этом. Пожилая женщина, которая попросила его подвезти её до'),
(15, 1, 0, 7, 8, 1, 1, 1, 1, 'pages', 'Ваккансии', '<p>В американском городе Северная Камбрия, штат Пенсильвания, был арестован не очень амбициозный грабитель, который попытался ограбить банк на сумму 1 доллар.&nbsp;<br /><br />50-летний Джеффри МакМуллен (Jeffrey McMullen) пришёл в банк AmeriServ Financial и дал работнику записку с требованием отдать ему 1 доллар. В начале работники банка подумали, что мужчина шутит, но он сказал, что это настоящее ограбление.&nbsp;<br /><br />Один из работников банка дал МакМуллену 1 доллар и позвонил в полицию. Мужчина сказал, что никуда уходить не собирается, и будет дожидаться полицейских.<br /><br />Прибывшие полицейские застали его на месте и сразу же арестовали. МакМуллен не оказывал никакого сопротивления. По всей видимости, он пытался добиться того, чтобы его арестовали, но причина такого поступка пока не известна.<br /><br />Полицейские сказали, что у МакМуллена не было криминального прошлого. Мужчина был заключён под стражу. Полицейские сказали, что отпустят его под залог в 50 тысяч долларов.</p>', 'vakkansii', 'Ваккансии', 'не, что, доллар, его, мужчина, полицейские, был, банк, под, арестовали, но, макмуллен, он, северная, дал, банка, сказали, американском, городе', 'В американском городе Северная Камбрия, штат Пенсильвания, был арестован не очень амбициозный грабитель, который попытался ограбить банк'),
(16, 1, 0, 15, 16, 1, 1, 1, 1, 'gallery', 'Галерея', '', 'galereya', 'Галерея', 'галерея', 'Галерея');

DROP TABLE IF EXISTS `redirects`;
CREATE TABLE `redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `old_url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `new_url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `old_url` (`old_url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `redirects` VALUES
(1, 1, '/magazin/', '/shop/');

DROP TABLE IF EXISTS `seo_links`;
CREATE TABLE `seo_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `limit` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `keyword` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

DROP TABLE IF EXISTS `seo_links-pages`;
CREATE TABLE `seo_links-pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `child` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

DROP TABLE IF EXISTS `seo_pages`;
CREATE TABLE `seo_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `exist` tinyint(1) unsigned NOT NULL COMMENT 'присутствует на сайте',
  `yandex_index` tinyint(1) unsigned NOT NULL,
  `yandex_check` datetime NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `links` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL COMMENT 'ИД ссылок',
  `articles` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL COMMENT 'ИД статтей',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

INSERT INTO `seo_pages` VALUES
(1, 1, 1, 0, '0000-00-00 00:00:00', '/', 'Главная', '145,1,7,154,10', ''),
(2, 1, 1, 0, '0000-00-00 00:00:00', '/korzina/', 'Корзина', '1,26,154,34,639', ''),
(3, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/8-Asus N53SV/', 'Asus N53SV', '10,181,145,1,774', ''),
(4, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/9-Lenovo IdeaPad B570A/', 'товар', '34,1,186,10,639', ''),
(5, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/dlya-raboty-i-ucheby/9-Lenovo IdeaPad B570A/', 'Каталог', '7,181,10,149,26', ''),
(6, 1, 1, 0, '0000-00-00 00:00:00', '/kontakty/', 'Контакты', '183,10,36,186,2', ''),
(7, 1, 1, 0, '0000-00-00 00:00:00', '/obratnaya-svyaz/', 'Обратная связь', '10,26,2,774,149', ''),
(8, 1, 1, 0, '0000-00-00 00:00:00', '/o-nas/', 'О нас', '181,774,186,36,10', '');

DROP TABLE IF EXISTS `shop_brands`;
CREATE TABLE `shop_brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rank` int(11) NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_brands` VALUES
(1, 1, 0, 'Samsung', 'samsung', 'samsung', 'Samsung', 'Samsung', ''),
(2, 1, 0, 'ASUS', 'asus', 'asus', 'ASUS', 'ASUS', ''),
(3, 1, 0, 'Lenovo', 'lenovo', 'lenovo', 'Lenovo', 'Lenovo', ''),
(4, 1, 0, 'Acer', 'acer', 'acer', 'Acer', 'Acer', '');

DROP TABLE IF EXISTS `shop_categories`;
CREATE TABLE `shop_categories` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `left_key` int(10) unsigned NOT NULL,
  `right_key` int(10) unsigned NOT NULL,
  `level` smallint(6) DEFAULT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `parameters` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=27 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_categories` VALUES
(1, 0, 1, 22, 1, 1, 'Компьютеры и ноутбуки', 'Компьютеры и ноутбуки', 'kompyutery-i-noutbuki', 'ноутбуки, компьютеры', 'Компьютеры и ноутбуки', 'notebooks_687896.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(2, 1, 2, 11, 2, 1, 'Ноутбуки', 'Ноутбуки', 'noutbuki', 'ноутбуки', 'Ноутбуки', 'notebooks_687896.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(3, 10, 13, 14, 3, 1, 'Серверы', 'Серверы', 'servery', 'серверы', 'Серверы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(14, 10, 17, 18, 3, 1, 'Начальный уровень', 'Начальный уровень', 'nachalnyi-uroven', 'уровень, начальный', 'Начальный уровень', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(4, 0, 23, 28, 1, 1, 'Телефоны', 'Телефоны', 'telefony', 'телефоны', 'Телефоны', '420.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(5, 4, 24, 25, 2, 1, 'Сотовые телефоны', 'Сотовые телефоны', 'sotovye-telefony', 'телефоны, сотовые', 'Сотовые телефоны', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(6, 4, 26, 27, 2, 1, 'Радиотелефоны', 'Радиотелефоны', 'radiotelefony', 'радиотелефоны', 'Радиотелефоны', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(7, 0, 31, 32, 1, 1, 'Активный отдых и туризм', 'Активный отдых и туризм', 'aktivnyi-otdyh-i-turizm', 'туризм, отдых, активный', 'Активный отдых и туризм', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(8, 2, 7, 10, 3, 1, 'Нетбуки', 'Нетбуки', 'netbuki', 'нетбуки', 'Нетбуки', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(9, 0, 29, 30, 1, 1, 'Бытовая техника, интерьер', 'Бытовая техника, интерьер', 'bytovaya-tehnika-interer', 'интерьер, техника, бытовая', 'Бытовая техника, интерьер', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(10, 1, 12, 21, 2, 1, 'Компьютеры', 'Компьютеры', 'kompyutery', 'компьютеры', 'Компьютеры', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(11, 8, 8, 9, 4, 1, 'Ультрабуки', 'Ультрабуки', 'ultrabuki', 'ультрабуки', 'Ультрабуки', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(12, 2, 3, 4, 3, 1, 'Начальный уровень', 'Начальный уровень', 'nachalnyi-uroven', 'уровень, начальный', 'Начальный уровень', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(13, 2, 5, 6, 3, 1, 'Для работы и учебы', 'Для работы и учебы', 'dlya-raboty-i-ucheby', 'учебы, работы, для', 'Для работы и учебы', '52.png', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(15, 10, 19, 20, 3, 1, 'Для работы и учебы', 'Для работы и учебы', 'dlya-raboty-i-ucheby', 'учебы, работы, для', 'Для работы и учебы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(16, 0, 33, 34, 1, 1, 'Товары для детей', 'Товары для детей', 'tovary-dlya-detei', 'детей, для, товары', 'Товары для детей', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(17, 0, 35, 36, 1, 1, 'Дом, сад', 'Дом, сад', 'dom-sad', 'сад, дом', 'Дом, сад', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(18, 10, 15, 16, 3, 1, 'Серверы2', 'Серверы', 'servery', 'серверы', 'Серверы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', '');

DROP TABLE IF EXISTS `shop_items`;
CREATE TABLE `shop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `n` tinyint(3) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

INSERT INTO `shop_items` VALUES
(28, 1, 3, 1, 'Hydrangeas', 'hydrangeas.jpg'),
(21, 1, 1, 1, 'Jellyfish', 'jellyfish.jpg'),
(26, 1, 4, 1, 'Hydrangeas', 'hydrangeas.jpg'),
(27, 1, 2, 1, 'Desert', 'desert.jpg');

DROP TABLE IF EXISTS `shop_parameters`;
CREATE TABLE `shop_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` mediumint(8) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `units` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `values` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_parameters` VALUES
(1, 10, 1, 'Процесор', '', 'a:2:{i:1;s:23:\"Intel Pentium Dual Core\";i:2;s:10:\"Intel Atom\";}', 1),
(2, 6, 2, 'Экран', 'дюймов', 'i:1;', 1),
(3, 8, 1, 'Расширение монитора', '', 'a:1:{i:1;s:8:\"1366x768\";}', 1),
(4, 2, 3, 'Bluetooth', '', 'a:2:{i:1;s:8:\"есть\";i:2;s:6:\"нет\";}', 1),
(5, 1, 3, 'Wi-Fi', '', 'a:2:{i:1;s:8:\"Есть\";i:2;s:6:\"Нет\";}', 1),
(6, 9, 2, 'Вес', 'кг.', '0', 1);

DROP TABLE IF EXISTS `shop_products`;
CREATE TABLE `shop_products` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `n` int(10) unsigned NOT NULL COMMENT 'глобальная сортировка',
  `article` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'артикул',
  `special` tinyint(1) DEFAULT '0',
  `rating` decimal(2,1) unsigned NOT NULL,
  `market` tinyint(1) unsigned NOT NULL COMMENT 'яндекс маркет',
  `category` int(10) unsigned NOT NULL,
  `categories` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `brand` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date` datetime DEFAULT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `price2` int(10) unsigned DEFAULT NULL,
  `similar` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `name1` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `text1` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `imgs` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `images` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `p1` int(10) unsigned NOT NULL,
  `p2` decimal(10,1) NOT NULL,
  `p3` int(10) unsigned NOT NULL,
  `p4` int(10) unsigned NOT NULL,
  `p5` int(10) unsigned NOT NULL,
  `p6` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `price` (`price`),
  KEY `category` (`category`),
  KEY `date` (`date`),
  KEY `special` (`special`),
  KEY `shop_brand` (`brand`),
  KEY `price_discount` (`price2`),
  KEY `display` (`display`),
  KEY `article` (`article`),
  KEY `p1` (`p1`),
  KEY `p2` (`p2`),
  KEY `p3` (`p3`),
  KEY `p4` (`p4`),
  KEY `p5` (`p5`),
  KEY `p6` (`p6`),
  KEY `n` (`n`)
) ENGINE=MyISAM AUTO_INCREMENT=22 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_products` VALUES
(1, 6, '122345', 1, '0.0', 0, 13, '', '1', '2010-12-28 11:49:34', 1, 1223, 1234, '', 'Acer Aspire AS5755G-2634G50Mnks', '', '', '', '', 'Acer Aspire AS5755G-2634G50Mnks', 'Экран 15.6&quot;, 1366x768, LED / Intel Pentium Dual Core P6000 (1.86 ГГц) / RAM 2 ГБ / HDD 320 ГБ / ATI Radeon HD 545v, 512 МБ / DVD Super Multi / LAN / Wi-Fi / веб-камера / DOS / 2.4 кг Acer Aspire AS5755G-2634G50Mnks', '<p>Экран 15.6&quot;, 1366x768, LED / Intel Pentium Dual Core P6000 (1.86 ГГц) / RAM 2 ГБ / HDD 320 ГБ / ATI Radeon HD 545v, 512 МБ / DVD Super Multi / LAN / Wi-Fi / веб-камера / DOS / 2.4 кг<span id=&quot;copyinfo&quot;><br /></span></p>', '2.jpg', 'a:4:{i:1;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"22.jpg\";s:4:\"name\";s:7:\"rqwerqw\";s:7:\"display\";s:1:\"1\";}i:2;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"23.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"24.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:4;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"25.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"22.jpg\";a:2:{s:4:\"name\";s:7:\"rqwerqw\";s:7:\"display\";s:1:\"1\";}s:6:\"23.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"24.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"25.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '11.0', 0, 0, 1, '2'),
(6, 1, '4564356', 1, '0.0', 0, 13, '', '1', '2010-12-28 12:10:48', 1, 538, 0, '', 'Asus K53BR', '', '', '', '', 'Asus K53BR', 'Asus K53BR (15,6&quot; HD(1366x768)/AMD DC E450/4Gb/500Gb/Radeon HD 7470, 1GB/DVD SM DL/Web-Cam 0.3Mp/Wi-Fi/BT/3xUSB/HDMI,VGA/CR3in1/DOS/6cell/2.6kg) Asus K53BR', '<p>Asus K53BR (15,6&quot; HD(1366x768)/AMD DC E450/4Gb/500Gb/Radeon HD 7470, 1GB/DVD SM DL/Web-Cam 0.3Mp/Wi-Fi/BT/3xUSB/HDMI,VGA/CR3in1/DOS/6cell/2.6kg)</p>', '31.jpg', 'a:4:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"32.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"33.jpg\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"34.jpg\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"35.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"32.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"33.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"34.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"35.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 0, 0, '0'),
(7, 4, '435643', 1, '0.0', 1, 13, '', '1', '2010-12-28 16:10:33', 1, 404, 0, '', 'Acer Aspire 5250-E302G32Mikk', '', '', '', '', 'Acer Aspire 5250-E302G32Mikk', 'dfgadfg Acer Aspire 5250-E302G32Mikk', '<p>Acer Aspire 5250-E302G32Mikk/15.6&quot; HD WXGAG/AMD DC E-300 1.3GHz/2GB/320GB/AMD Radeon HD6310M/DVD SM/LAN/WiFi GN/CR 2in1/HDMI/Cam 0.3M/OS Linux/4400 mAh 6-cell/2.6 kg</p>', '1.jpg', 'a:2:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"11.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:2:{s:6:\"11.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 0, 0, '0'),
(8, 5, '456345', 1, '5.0', 0, 13, '', '2', '2011-02-25 16:38:46', 1, 905, 190, '', 'Asus N53SV', '', '', '', 'asus, n53sv, i7-2630qm, core, n53sv-sx633d, 1366x768', 'Asus N53SV', 'N53SV-SX633D Asus N53SV (15.6\'\' (1366x768) LED/Core i7-2630QM(2.0 GHz)/4Gb/500Gb/GeForce GT540M, 1Gb/DVD SM/LAN/Wi-Fi/BT/HDMI/Web-Cam/CR3in1/DOS/6cell/2.7kg) Asus N53SV', '<p>Asus N53SV (15.6\'\' (1366x768) LED/Core i7-2630QM(2.0 GHz)/4Gb/500Gb/GeForce GT540M, 1Gb/DVD SM/LAN/Wi-Fi/BT/HDMI/Web-Cam/CR3in1/DOS/6cell/2.7kg)</p>', '11.jpg', 'a:4:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"13.jpg\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"14.jpg\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"15.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"15.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 1, 1, '1'),
(9, 2, '3456456', 0, '5.0', 1, 13, '12,13', '4', '2011-02-25 16:39:35', 1, 0, 0, '', 'товар', '', '', '', '', 'Lenovo IdeaPad B570A', 'Lenovo IdeaPad B570A 15.6&quot; (1366x768) LED, глянцевый/Intel Core i5-2430M (2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / nVidia GeForce 410M, 1 ГБ / DVD+/-RW / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.35 кг Lenovo IdeaPad B570A', '<p>Lenovo IdeaPad B570A 15.6&quot; (1366x768) LED, глянцевый/Intel Core i5-2430M (2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / nVidia GeForce 410M, 1 ГБ / DVD+/-RW / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.35 кг</p>', '11.jpg', 'a:3:{i:1;a:3:{s:4:\"file\";s:6:\"12.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"file\";s:6:\"13.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"file\";s:6:\"14.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:3:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '14.0', 1, 0, 0, '4'),
(10, 3, '34563456', 1, '2.5', 1, 13, '', '1', '2011-02-25 16:39:35', 1, 6373, 0, '1', 'Samsung Series', 'Samsung Series', '', '', '', 'Samsung Series 3', 'Samsung Series 3 15,6\'\' (1366x768)HD LED, матовый/Intel Core i3-2310M (2.1 ГГц)/RAM 3 ГБ/HDD 320 ГБ/nVidia GFce 520MX, 1 ГБ/DVD Super Multi/LAN/Wi-Fi/Bluetooth 3.0/веб-камера/DOS/2.45 кг/черный 628.00 Samsung Series 3', '<p>Samsung Series 3 15,6\'\' (1366x768)HD LED, матовый/Intel Core i3-2310M (2.1 ГГц)/RAM 3 ГБ/HDD 320 ГБ/nVidia GFce 520MX, 1 ГБ/DVD Super Multi/LAN/Wi-Fi/Bluetooth 3.0/веб-камера/DOS/2.45 кг/черный</p>', '11.jpg', 'a:3:{i:1;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:2;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"13.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"14.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:3:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 1, '0.0', 1, 0, 1, '11');

DROP TABLE IF EXISTS `shop_products-categories`;
CREATE TABLE `shop_products-categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `child` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `child` (`child`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `shop_reviews`;
CREATE TABLE `shop_reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rating` tinyint(1) unsigned NOT NULL,
  `product` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `product` (`product`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_reviews` VALUES
(1, 1, 4, 10, '2014-05-27 14:29:52', 'Дмитрий', 'ottofonf@gmail.com', '<p>первый отзыв о товаре<br />в две строчки</p>'),
(6, 0, 5, 9, '2015-04-12 15:46:05', 'Верстка и программирование', 'ottofonf@rambler.ru', '<p>вапывап</p>'),
(4, 0, 5, 9, '2015-04-12 15:35:17', 'ertyet', 'ottofonf@rambler.ru', '<p>ertyerty</p>'),
(5, 0, 5, 9, '2015-04-12 15:42:37', 'erter', 'ottofonf@rambler.ru', '<p>tert</p>');

DROP TABLE IF EXISTS `slider`;
CREATE TABLE `slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rank` int(11) NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `slider` VALUES
(1, 1, 10, 'Пустыня', '', '<p>qwerty<br />dfeafsadf<br /><span style=\"line-height: 1.5;\">sadf&nbsp;</span></p>', 'desert.jpg'),
(2, 1, 8, 'Пингвины', '', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.&nbsp;</p>', 'penguins.jpg'),
(3, 1, 1, 'Коала', '', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'koala.jpg');

DROP TABLE IF EXISTS `subscribe_letters`;
CREATE TABLE `subscribe_letters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `subject` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `subscribe_letters` VALUES
(1, '2013-12-11 14:33:27', 'Первая пробная рассылка', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'текст первой рассылки\r\n<br />\r\nвот такой');

DROP TABLE IF EXISTS `subscribers`;
CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `surname` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `subscribers` VALUES
(1, 1, '2013-12-11 13:56:59', 'ottofonf@gmail.com', 'Дмитрий', 'Смаль');

DROP TABLE IF EXISTS `user_fields`;
CREATE TABLE `user_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` int(11) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `required` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `hint` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `values` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `user_fields` VALUES
(1, 10, 1, 1, 1, 'Адрес', '', ''),
(2, 2, 1, 2, 1, 'Статус', '', 'a:2:{i:1;s:29:\"физическое лицо\";i:2;s:31:\"юридическое лицо\";}'),
(3, 12, 1, 1, 1, 'Имя', '', ''),
(4, 1, 1, 3, 0, 'О себе', '', '');

DROP TABLE IF EXISTS `user_types`;
CREATE TABLE `user_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_admin` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `access_delete` tinyint(1) unsigned DEFAULT NULL,
  `access_ftp` tinyint(1) unsigned DEFAULT NULL,
  `access_editable` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ut_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `user_types` VALUES
(1, 'a:40:{i:0;s:5:\"pages\";i:1;s:4:\"news\";i:2;s:7:\"gallery\";i:3;s:6:\"slider\";i:4;s:9:\"languages\";i:5;s:8:\"feedback\";i:6;s:13:\"shop_products\";i:7;s:15:\"shop_categories\";i:8;s:11:\"shop_brands\";i:9;s:15:\"shop_parameters\";i:10;s:12:\"shop_reviews\";i:11;s:11:\"shop_export\";i:12;s:11:\"shop_import\";i:13;s:6:\"orders\";i:14;s:11:\"order_types\";i:15;s:16:\"order_deliveries\";i:16;s:14:\"order_payments\";i:17;s:5:\"users\";i:18;s:10:\"user_types\";i:19;s:11:\"user_fields\";i:20;s:11:\"subscribers\";i:21;s:17:\"subscribe_letters\";i:22;s:7:\"letters\";i:23;s:6:\"config\";i:24;s:16:\"letter_templates\";i:25;s:4:\"logs\";i:26;s:12:\"template_css\";i:27;s:15:\"template_images\";i:28;s:17:\"template_includes\";i:29;s:16:\"template_scripts\";i:30;s:6:\"backup\";i:31;s:7:\"restore\";i:32;s:9:\"redirects\";i:33;s:10:\"seo_robots\";i:34;s:11:\"seo_sitemap\";i:35;s:12:\"seo_htaccess\";i:36;s:9:\"seo_links\";i:37;s:9:\"seo_pages\";i:38;s:16:\"seo_links_import\";i:39;s:16:\"seo_links_export\";}', 1, 1, 'a:9:{i:0;s:10:\"dictionary\";i:1;s:5:\"pages\";i:2;s:4:\"news\";i:3;s:13:\"shop_products\";i:4;s:15:\"shop_categories\";i:5;s:11:\"shop_brands\";i:6;s:12:\"shop_reviews\";i:7;s:11:\"user_fields\";i:8;s:16:\"order_deliveries\";}', 'Администраторы');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `date` datetime NOT NULL COMMENT 'дата регистрации',
  `remind` datetime NOT NULL,
  `last_visit` datetime NOT NULL COMMENT 'время последней авторизации',
  `remember_me` tinyint(1) unsigned NOT NULL COMMENT 'запомнить меня',
  `type` tinyint(1) unsigned DEFAULT NULL COMMENT 'группа пользователей',
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'логин',
  `hash` varchar(32) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'hash',
  `avatar` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'изображение',
  `fields` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'динамические характеристики',
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`email`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ PACK_KEYS=0 COMMENT='Пользователи';

INSERT INTO `users` VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-05-23 23:25:04', 1, 1, 'admin', 'bbccfd97fdd9dd272302336ae596423f', '', 'a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}'),
(2, '2010-11-25 20:57:04', '0000-00-00 00:00:00', '2015-04-06 12:23:01', 1, 1, 'test', '3f14b6841ab09dc36d32a3d6f80ade58', '', 'a:4:{i:3;a:1:{i:0;s:8:\"тест\";}i:1;a:1:{i:0;s:8:\"тест\";}i:2;a:1:{i:0;s:29:\"физическое лицо\";}i:4;a:1:{i:0;s:8:\"тест\";}}');

